_parameters = dict(host='p-bankapi-01.hq.ru.corp.leroymerlin.com', database='bankapiconnector', user='bankapiconnector',
                  password='4ivu34mq3ryFiqYc', port=6435)